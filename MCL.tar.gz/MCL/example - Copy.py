# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 12:12:12 2018

@author: SWAGATA MAITY
"""

import numpy 
import Graph
import MarkovClustering
import networkx as nx
import matplotlib.pyplot as plt
        
f = open("input adjacency matrix.txt", "r")

G = nx.Graph()
 
grafo = Graph.Graph()
for line in f:
    edges = line.split()
    if(line!='\n'):
        G.add_edge(edges[0], edges[1])
        grafo.addNode(edges[0], edges[0])
        grafo.addNode(edges[1], edges[1])
        grafo.addEdge(edges[0], edges[1])


#print ("Graph adjacency list representation: \n",grafo)    
#nx.draw(G,with_labels=True)
#plt.show()
matrix, mapBackToKeys = grafo.getGraphMatrix()
numpymat = numpy.array(matrix)
print ("Graph-> Adjacency matrix representation: \n",numpymat)
print ("\nMapping matrix indexes to keys: ", mapBackToKeys)

alg = MarkovClustering.MarkovClustering(matrix,e=2,r=2)
clusters = alg.computeClusters(T=40)

print ("\nClusters after MCL algorithm: ")
with open('cluster.txt','w') as f:
    for cluster in clusters:
        print ([mapBackToKeys[x] for x in cluster])
        f.write('[')
        for x in cluster:
            f.write(mapBackToKeys[x]+',')
        f.write(']'+'\n')    
 
#printing the network
"""
pos = nx.shell_layout(G)
nx.draw(G)
plt.savefig("graph_testing.png")
plt.show()
"""
