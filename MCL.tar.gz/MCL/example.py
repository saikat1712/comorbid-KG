# -*- coding: utf-8 -*-
"""
Created on Mon Jun 25 12:12:12 2018

@author: SWAGATA MAITY
"""
import numpy 
import Graph
import MarkovClustering
        
f = open("New.txt", "r")

grafo = Graph.Graph()
for line in f:
    edges = line.split()
    if(line!='\n'):
        grafo.addNode(edges[0], edges[0])
        grafo.addNode(edges[1], edges[1])
        grafo.addEdge(edges[0], edges[1])

#print ("Graph adjacency list representation: \n",grafo)    
matrix, mapBackToKeys = grafo.getGraphMatrix()
numpymat = numpy.array(matrix)
print ("Graph: Adjacency matrix representation: \n",numpymat)
#print ("\nMapping matrix indexes to keys: ", mapBackToKeys)

alg = MarkovClustering.MarkovClustering(matrix,e=2,r=2)
clusters = alg.computeClusters(T=40)

print ("\nClusters after MCL algorithm: ")
with open('cluster_sir_matrix_final.txt','w') as f:
    for cluster in clusters:
        #print ([mapBackToKeys[x] for x in cluster])
        for x in cluster:
            f.write(mapBackToKeys[x]+',')
        f.write(';'+'\n')    

pos = nx.shell_layout(G)
nx.draw(G,with_labels=True)
plt.savefig("graph_testing.png")
plt.show() 